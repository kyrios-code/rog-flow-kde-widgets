#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/plasma/plasmoids/io.rog.gaminghud"
HELPER="$HOME/.local/bin/rog-gaming-helper"
mkdir -p "$HOME/.local/bin" "$(dirname "$DEST")"
if [[ -d "$DEST" ]]; then
 mkdir -p "$HOME/.local/share/rog-gaming-hud-backups"
 mv "$DEST" "$HOME/.local/share/rog-gaming-hud-backups/$(date +%Y%m%d-%H%M%S)-$$"
fi
cp -a "$HERE/package" "$DEST"
install -m 755 "$HERE/rog-gaming-helper.py" "$HELPER"
python3 - "$DEST/contents/ui/main.qml" "$HELPER" <<'PY'
import pathlib,sys
p=pathlib.Path(sys.argv[1]);p.write_text(p.read_text().replace("__HELPER__",sys.argv[2]))
PY
echo "Installed ROG Gaming HUD. Add through Plasma Edit Mode > Add Widgets."
