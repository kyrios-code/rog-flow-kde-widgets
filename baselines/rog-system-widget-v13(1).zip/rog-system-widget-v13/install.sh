#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.local/share/plasma/plasmoids/io.rog.systemwidget"
HELPER="$HOME/.local/bin/rog-z13-telemetry"
mkdir -p "$HOME/.local/bin" "$(dirname "$DEST")"
if [[ -d "$DEST" ]]; then
    mkdir -p "$HOME/.local/share/rog-system-widget-backups"
    mv "$DEST" "$HOME/.local/share/rog-system-widget-backups/$(date +%Y%m%d-%H%M%S)-$$"
fi
cp -a "$ROOT/package" "$DEST"
install -m 755 "$ROOT/telemetry.py" "$HELPER"
python3 - "$DEST/contents/ui/main.qml" "$HELPER" <<'PY'
import pathlib,sys
p=pathlib.Path(sys.argv[1])
p.write_text(p.read_text().replace("__HELPER_PATH__",sys.argv[2]))
PY
echo "Installed ROG System Widget 0.8."
echo "In Plasma: Edit Mode > Add Widgets > ROG System Widget."
echo "Keep your known-good ROG System Widget backup until this build is verified."
